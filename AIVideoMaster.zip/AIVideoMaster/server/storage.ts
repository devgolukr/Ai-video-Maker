import { 
  users, 
  videoGenerations,
  type User, 
  type InsertUser,
  type VideoGeneration,
  type InsertVideoGeneration,
  type UpdateVideoGeneration
} from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Video generation methods
  createVideoGeneration(generation: InsertVideoGeneration): Promise<VideoGeneration>;
  getVideoGeneration(id: number): Promise<VideoGeneration | undefined>;
  updateVideoGeneration(id: number, updates: UpdateVideoGeneration): Promise<VideoGeneration | undefined>;
  getUserVideoGenerations(userId?: number): Promise<VideoGeneration[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private videoGenerations: Map<number, VideoGeneration>;
  private currentUserId: number;
  private currentVideoId: number;

  constructor() {
    this.users = new Map();
    this.videoGenerations = new Map();
    this.currentUserId = 1;
    this.currentVideoId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createVideoGeneration(generation: InsertVideoGeneration): Promise<VideoGeneration> {
    const id = this.currentVideoId++;
    const videoGeneration: VideoGeneration = {
      id,
      prompt: generation.prompt,
      duration: generation.duration || null,
      style: generation.style || null,
      voiceGender: generation.voiceGender || null,
      status: "pending",
      script: null,
      audioUrl: null,
      videoUrl: null,
      metadata: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.videoGenerations.set(id, videoGeneration);
    return videoGeneration;
  }

  async getVideoGeneration(id: number): Promise<VideoGeneration | undefined> {
    return this.videoGenerations.get(id);
  }

  async updateVideoGeneration(id: number, updates: UpdateVideoGeneration): Promise<VideoGeneration | undefined> {
    const existing = this.videoGenerations.get(id);
    if (!existing) return undefined;

    const updated: VideoGeneration = {
      ...existing,
      ...updates,
      updatedAt: new Date(),
    };
    this.videoGenerations.set(id, updated);
    return updated;
  }

  async getUserVideoGenerations(userId?: number): Promise<VideoGeneration[]> {
    // For simplicity, return all generations (in a real app, filter by userId)
    return Array.from(this.videoGenerations.values())
      .sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime());
  }
}

export const storage = new MemStorage();
