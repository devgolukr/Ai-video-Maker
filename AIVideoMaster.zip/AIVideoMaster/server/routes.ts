import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertVideoGenerationSchema } from "@shared/schema";
import { generateVideoScript, optimizeScriptForFootage } from "./services/gemini";
import { generateSceneVoiceovers } from "./services/elevenlabs";
import { findFootageForScenes } from "./services/stockFootage";
import { createSimpleVideo } from "./services/simpleVideoProcessor";
import { createEnhancedVideo } from "./services/enhancedVideoProcessor";
import multer from "multer";
import path from "path";
import fs from "fs";

// Setup file uploads
const upload = multer({ 
  dest: "uploads/",
  limits: { fileSize: 500 * 1024 * 1024 } // 500MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Serve uploaded files
  app.use("/uploads", (req, res, next) => {
    const filePath = path.join(process.cwd(), "uploads", req.path);
    if (fs.existsSync(filePath)) {
      res.sendFile(filePath);
    } else {
      res.status(404).json({ message: "File not found" });
    }
  });

  // Create video generation request
  app.post("/api/video-generation", async (req, res) => {
    try {
      const validatedData = insertVideoGenerationSchema.parse(req.body);
      
      const generation = await storage.createVideoGeneration(validatedData);
      
      // Start video generation process asynchronously
      generateVideoAsync(generation.id).catch(error => {
        console.error("Video generation failed:", error);
        storage.updateVideoGeneration(generation.id, {
          status: "failed",
          metadata: { error: error.message }
        });
      });

      res.json(generation);
    } catch (error) {
      res.status(400).json({ message: "Invalid request data", error: (error as Error).message });
    }
  });

  // Get video generation status
  app.get("/api/video-generation/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const generation = await storage.getVideoGeneration(id);
      
      if (!generation) {
        return res.status(404).json({ message: "Video generation not found" });
      }

      res.json(generation);
    } catch (error) {
      res.status(500).json({ message: "Failed to get video generation", error: (error as Error).message });
    }
  });

  // List video generations
  app.get("/api/video-generations", async (req, res) => {
    try {
      const generations = await storage.getUserVideoGenerations();
      res.json(generations);
    } catch (error) {
      res.status(500).json({ message: "Failed to get video generations", error: (error as Error).message });
    }
  });

  // Download video
  app.get("/api/video-generation/:id/download", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const generation = await storage.getVideoGeneration(id);
      
      if (!generation || !generation.videoUrl) {
        return res.status(404).json({ message: "Video not found or not ready" });
      }

      const videoPath = path.join(process.cwd(), generation.videoUrl.replace('/uploads/', 'uploads/'));
      
      if (!fs.existsSync(videoPath)) {
        return res.status(404).json({ message: "Video file not found" });
      }

      const filename = `VideoForge_AI_${generation.id}.mp4`;
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.setHeader('Content-Type', 'video/mp4');
      
      const stream = fs.createReadStream(videoPath);
      stream.pipe(res);
    } catch (error) {
      res.status(500).json({ message: "Failed to download video", error: (error as Error).message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

async function generateVideoAsync(generationId: number): Promise<void> {
  try {
    // Update status to processing
    await storage.updateVideoGeneration(generationId, { status: "processing" });
    
    const generation = await storage.getVideoGeneration(generationId);
    if (!generation) throw new Error("Generation not found");

    // Step 1: Generate script
    console.log("Generating script...");
    const script = await generateVideoScript(
      generation.prompt,
      generation.duration || "2 minutes",
      generation.style || "professional"
    );
    
    await storage.updateVideoGeneration(generationId, { 
      script: JSON.stringify(script),
      metadata: { currentStep: "voiceover", progress: 25 }
    });

    // Step 2: Optimize script for footage
    console.log("Optimizing script for footage...");
    const optimizedScript = await optimizeScriptForFootage(script);

    // Step 3: Generate voiceovers
    console.log("Generating voiceovers...");
    const audioFiles = await generateSceneVoiceovers(
      optimizedScript.scenes,
      { 
        gender: generation.voiceGender || "neutral",
        tone: optimizedScript.tone 
      }
    );
    
    await storage.updateVideoGeneration(generationId, {
      metadata: { currentStep: "footage", progress: 50 }
    });

    // Step 4: Find stock footage
    console.log("Finding stock footage...");
    const footage = await findFootageForScenes(optimizedScript.scenes);
    
    await storage.updateVideoGeneration(generationId, {
      metadata: { currentStep: "editing", progress: 75 }
    });

    // Step 5: Create video
    console.log("Creating video...");
    const outputPath = path.join("uploads", "videos", `video_${generationId}.mp4`);
    
    // Ensure videos directory exists
    const videosDir = path.dirname(outputPath);
    if (!fs.existsSync(videosDir)) {
      fs.mkdirSync(videosDir, { recursive: true });
    }

    const finalVideoPath = await createEnhancedVideo(
      audioFiles,
      footage,
      {
        outputPath,
        resolution: "1080p"
      }
    );

    // Update final status
    await storage.updateVideoGeneration(generationId, {
      status: "completed",
      videoUrl: `/uploads/videos/video_${generationId}.mp4`,
      metadata: { 
        currentStep: "completed", 
        progress: 100,
        script: optimizedScript,
        audioFiles: audioFiles.length,
        videoClips: footage.reduce((acc, scene) => acc + scene.clips.length, 0)
      }
    });

    console.log("Video generation completed successfully!");
  } catch (error) {
    console.error("Video generation failed:", error);
    await storage.updateVideoGeneration(generationId, {
      status: "failed",
      metadata: { error: (error as Error).message }
    });
    throw error;
  }
}
