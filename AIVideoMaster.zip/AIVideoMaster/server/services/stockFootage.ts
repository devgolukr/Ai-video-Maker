export interface VideoClip {
  id: string;
  url: string;
  downloadUrl: string;
  duration: number;
  width: number;
  height: number;
  tags: string[];
  description: string;
}

export async function searchStockFootage(keywords: string[]): Promise<VideoClip[]> {
  try {
    // Using Pexels API for stock footage
    const apiKey = process.env.PEXELS_API_KEY;
    
    if (!apiKey) {
      throw new Error("Pexels API key is required");
    }
    
    // Try multiple search strategies
    const searchQueries = [
      keywords.join(" "),
      // Fallback to English equivalents for common Hindi terms
      keywords.join(" ").replace(/रीसाइक्लिंग/g, "recycling")
                        .replace(/पर्यावरण/g, "environment")
                        .replace(/प्रकृति/g, "nature")
                        .replace(/तकनीक/g, "technology")
                        .replace(/शिक्षा/g, "education"),
      // Generic fallbacks
      "nature environment",
      "technology innovation",
      "business office"
    ];

    for (const query of searchQueries) {
      console.log(`Searching with query: ${query}`);
      
      const response = await fetch(
        `https://api.pexels.com/videos/search?query=${encodeURIComponent(query)}&per_page=10&orientation=landscape`,
        {
          headers: {
            "Authorization": apiKey
          }
        }
      );

      if (!response.ok) {
        console.error(`Pexels API error for query "${query}": ${response.status} ${response.statusText}`);
        continue;
      }

      const data = await response.json();
      console.log(`Found ${data.videos?.length || 0} videos for query: ${query}`);
      
      if (data.videos && data.videos.length > 0) {
        return data.videos.map((video: any) => ({
          id: video.id.toString(),
          url: video.video_preview,
          downloadUrl: video.video_files?.find((file: any) => 
            file.quality === "hd" || file.quality === "sd"
          )?.link || video.video_files[0]?.link,
          duration: video.duration || 10,
          width: video.width,
          height: video.height,
          tags: video.tags || [],
          description: video.tags?.join(", ") || ""
        }));
      }
    }
    
    // If no videos found, return empty array
    console.warn("No videos found for any search query");
    return [];
  } catch (error) {
    console.error("Failed to search stock footage:", error);
    return [];
  }
}

export async function downloadVideoClip(videoClip: VideoClip): Promise<string> {
  try {
    const response = await fetch(videoClip.downloadUrl);
    if (!response.ok) {
      throw new Error(`Failed to download video: ${response.status}`);
    }

    const buffer = await response.arrayBuffer();
    const filename = `clip_${videoClip.id}_${Date.now()}.mp4`;
    const filepath = path.join(process.cwd(), "uploads", "clips", filename);
    
    // Ensure clips directory exists
    const clipsDir = path.dirname(filepath);
    if (!fs.existsSync(clipsDir)) {
      fs.mkdirSync(clipsDir, { recursive: true });
    }
    
    fs.writeFileSync(filepath, Buffer.from(buffer));
    return filepath;
  } catch (error) {
    throw new Error(`Failed to download video clip: ${error}`);
  }
}

export async function findFootageForScenes(
  scenes: Array<{ keywords: string[]; duration: number; visualDescription: string }>
): Promise<Array<{ clips: VideoClip[]; targetDuration: number }>> {
  const sceneFootage = [];
  
  for (const scene of scenes) {
    try {
      const clips = await searchStockFootage(scene.keywords);
      sceneFootage.push({
        clips: clips.slice(0, 3), // Take top 3 clips per scene
        targetDuration: scene.duration
      });
    } catch (error) {
      console.error(`Failed to find footage for scene:`, error);
      sceneFootage.push({
        clips: [],
        targetDuration: scene.duration
      });
    }
  }
  
  return sceneFootage;
}

import fs from "fs";
import path from "path";
