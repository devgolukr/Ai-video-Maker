import { spawn } from "child_process";
import fs from "fs";
import path from "path";
import { VideoClip } from "./stockFootage";

export interface VideoProcessingOptions {
  outputPath: string;
  resolution: "720p" | "1080p";
  fps: number;
}

export async function createVideoFromAssets(
  audioFiles: Array<{ audioUrl: string; duration: number }>,
  videoClips: Array<{ clips: VideoClip[]; targetDuration: number }>,
  options: VideoProcessingOptions
): Promise<string> {
  try {
    const tempDir = path.join(process.cwd(), "temp", `video_${Date.now()}`);
    if (!fs.existsSync(tempDir)) {
      fs.mkdirSync(tempDir, { recursive: true });
    }

    // Create individual scene videos
    const sceneVideos: string[] = [];
    
    for (let i = 0; i < audioFiles.length && i < videoClips.length; i++) {
      const audioFile = audioFiles[i];
      const sceneClips = videoClips[i];
      
      if (sceneClips.clips.length > 0) {
        const sceneVideoPath = await createSceneVideo(
          audioFile,
          sceneClips,
          tempDir,
          i,
          options
        );
        sceneVideos.push(sceneVideoPath);
      }
    }

    // Concatenate all scene videos
    const finalVideoPath = await concatenateVideos(sceneVideos, options.outputPath);
    
    // Cleanup temp files
    cleanupTempFiles(tempDir);
    
    return finalVideoPath;
  } catch (error) {
    throw new Error(`Failed to create video: ${error}`);
  }
}

async function createSceneVideo(
  audio: { audioUrl: string; duration: number },
  sceneClips: { clips: VideoClip[]; targetDuration: number },
  tempDir: string,
  sceneIndex: number,
  options: VideoProcessingOptions
): Promise<string> {
  return new Promise((resolve, reject) => {
    const outputPath = path.join(tempDir, `scene_${sceneIndex}.mp4`);
    const audioPath = path.join(process.cwd(), audio.audioUrl.replace('/uploads/', 'uploads/'));
    
    // Use the first available clip for this scene
    const clip = sceneClips.clips[0];
    if (!clip) {
      reject(new Error(`No video clip available for scene ${sceneIndex}`));
      return;
    }

    // Resolution settings
    const resolutionMap = {
      "720p": "1280x720",
      "1080p": "1920x1080"
    };

    // Fix the video filter for proper scaling and padding
    const [width, height] = resolutionMap[options.resolution].split('x');
    
    const args = [
      "-i", clip.downloadUrl, // Video input
      "-i", audioPath, // Audio input
      "-c:v", "libx264",
      "-c:a", "aac",
      "-vf", `scale=${width}:${height}:force_original_aspect_ratio=decrease,pad=${width}:${height}:(ow-iw)/2:(oh-ih)/2,fps=${options.fps}`,
      "-shortest", // Use shortest input duration
      "-y", // Overwrite output file
      outputPath
    ];

    const ffmpeg = spawn("ffmpeg", args);
    
    ffmpeg.stderr.on("data", (data) => {
      console.log(`FFmpeg stderr: ${data}`);
    });

    ffmpeg.on("close", (code) => {
      if (code === 0) {
        resolve(outputPath);
      } else {
        reject(new Error(`FFmpeg process exited with code ${code}`));
      }
    });

    ffmpeg.on("error", (error) => {
      reject(new Error(`FFmpeg spawn error: ${error}`));
    });
  });
}

async function concatenateVideos(videoPaths: string[], outputPath: string): Promise<string> {
  return new Promise((resolve, reject) => {
    if (videoPaths.length === 0) {
      reject(new Error("No videos to concatenate"));
      return;
    }

    if (videoPaths.length === 1) {
      // If only one video, just copy it
      fs.copyFileSync(videoPaths[0], outputPath);
      resolve(outputPath);
      return;
    }

    // Create concat file list
    const concatListPath = path.join(path.dirname(outputPath), "concat_list.txt");
    const concatContent = videoPaths.map(p => `file '${p}'`).join("\n");
    fs.writeFileSync(concatListPath, concatContent);

    const args = [
      "-f", "concat",
      "-safe", "0",
      "-i", concatListPath,
      "-c", "copy",
      "-y",
      outputPath
    ];

    const ffmpeg = spawn("ffmpeg", args);
    
    ffmpeg.stderr.on("data", (data) => {
      console.log(`FFmpeg concat stderr: ${data}`);
    });

    ffmpeg.on("close", (code) => {
      // Cleanup concat list file
      if (fs.existsSync(concatListPath)) {
        fs.unlinkSync(concatListPath);
      }
      
      if (code === 0) {
        resolve(outputPath);
      } else {
        reject(new Error(`FFmpeg concat process exited with code ${code}`));
      }
    });

    ffmpeg.on("error", (error) => {
      reject(new Error(`FFmpeg concat spawn error: ${error}`));
    });
  });
}

function cleanupTempFiles(tempDir: string): void {
  try {
    if (fs.existsSync(tempDir)) {
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  } catch (error) {
    console.warn("Failed to cleanup temp files:", error);
  }
}

export async function addTransitionsToVideo(inputPath: string, outputPath: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const args = [
      "-i", inputPath,
      "-vf", "fade=in:0:30,fade=out:st=end-1:d=1", // Add fade in/out transitions
      "-c:a", "copy",
      "-y",
      outputPath
    ];

    const ffmpeg = spawn("ffmpeg", args);
    
    ffmpeg.stderr.on("data", (data) => {
      console.log(`FFmpeg transitions stderr: ${data}`);
    });

    ffmpeg.on("close", (code) => {
      if (code === 0) {
        resolve(outputPath);
      } else {
        reject(new Error(`FFmpeg transitions process exited with code ${code}`));
      }
    });

    ffmpeg.on("error", (error) => {
      reject(new Error(`FFmpeg transitions spawn error: ${error}`));
    });
  });
}
