import fs from "fs";
import path from "path";

export interface VoiceOptions {
  gender: string;
  tone: string;
}

export async function generateVoiceover(
  text: string,
  options: VoiceOptions
): Promise<string> {
  try {
    const apiKey = process.env.ELEVENLABS_API_KEY;
    
    if (!apiKey) {
      throw new Error("ElevenLabs API key is required");
    }
    
    // Select voice based on gender preference
    const voiceId = getVoiceId(options.gender);
    
    const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
      method: "POST",
      headers: {
        "Accept": "audio/mpeg",
        "Content-Type": "application/json",
        "xi-api-key": apiKey
      },
      body: JSON.stringify({
        text,
        model_id: "eleven_multilingual_v2",
        voice_settings: {
          stability: 0.5,
          similarity_boost: 0.5,
          style: 0.5,
          use_speaker_boost: true
        }
      })
    });

    if (!response.ok) {
      throw new Error(`ElevenLabs API error: ${response.status} ${response.statusText}`);
    }

    const audioBuffer = await response.arrayBuffer();
    const filename = `voiceover_${Date.now()}.mp3`;
    const filepath = path.join(process.cwd(), "uploads", filename);
    
    // Ensure uploads directory exists
    const uploadsDir = path.dirname(filepath);
    if (!fs.existsSync(uploadsDir)) {
      fs.mkdirSync(uploadsDir, { recursive: true });
    }
    
    fs.writeFileSync(filepath, Buffer.from(audioBuffer));
    
    return `/uploads/${filename}`;
  } catch (error) {
    throw new Error(`Failed to generate voiceover: ${error}`);
  }
}

function getVoiceId(gender: string): string {
  // ElevenLabs voice IDs - using some of their default voices
  const voices = {
    male: "pNInz6obpgDQGcFmaJgB", // Adam
    female: "21m00Tcm4TlvDq8ikWAM", // Rachel
    neutral: "AZnzlk1XvdvUeBnXmlld" // Domi
  };
  
  return voices[gender as keyof typeof voices] || voices.neutral;
}

export async function generateSceneVoiceovers(
  scenes: Array<{ narration: string; duration: number }>,
  options: VoiceOptions
): Promise<Array<{ audioUrl: string; duration: number }>> {
  const audioFiles: Array<{ audioUrl: string; duration: number }> = [];
  
  for (const scene of scenes) {
    try {
      const audioUrl = await generateVoiceover(scene.narration, options);
      audioFiles.push({
        audioUrl,
        duration: scene.duration
      });
    } catch (error) {
      console.error(`Failed to generate voiceover for scene:`, error);
      // Continue with other scenes even if one fails
    }
  }
  
  return audioFiles;
}
