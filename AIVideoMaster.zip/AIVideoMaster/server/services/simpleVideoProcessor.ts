import { spawn } from "child_process";
import fs from "fs";
import path from "path";
import { VideoClip } from "./stockFootage";

export interface SimpleVideoOptions {
  outputPath: string;
  resolution: "720p" | "1080p";
}

export async function createSimpleVideo(
  audioFiles: Array<{ audioUrl: string; duration: number }>,
  videoClips: Array<{ clips: VideoClip[]; targetDuration: number }>,
  options: SimpleVideoOptions
): Promise<string> {
  try {
    // Ensure we have at least one audio file and one video clip
    if (audioFiles.length === 0 || videoClips.length === 0) {
      throw new Error("No audio files or video clips available");
    }

    const tempDir = path.join(process.cwd(), "temp", `simple_video_${Date.now()}`);
    if (!fs.existsSync(tempDir)) {
      fs.mkdirSync(tempDir, { recursive: true });
    }

    // Use the first audio file and first available video clip
    const audioFile = audioFiles[0];
    const videoClip = videoClips[0]?.clips[0];
    
    if (!videoClip) {
      // Fallback: use a solid color background with text overlay
      console.log("No video clips available, creating text-based video");
      return await createTextOnlyVideo(audioFiles, options);
    }

    const audioPath = path.join(process.cwd(), audioFile.audioUrl.replace('/uploads/', 'uploads/'));
    
    // Verify audio file exists
    if (!fs.existsSync(audioPath)) {
      throw new Error(`Audio file not found: ${audioPath}`);
    }

    // Create a simple video with basic settings
    const outputPath = options.outputPath;
    
    // Ensure output directory exists
    const outputDir = path.dirname(outputPath);
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
    }

    // Simple FFmpeg command that should work reliably
    const resolutionMap = {
      "720p": { width: 1280, height: 720 },
      "1080p": { width: 1920, height: 1080 }
    };
    
    const { width, height } = resolutionMap[options.resolution];

    await new Promise<void>((resolve, reject) => {
      const args = [
        "-i", videoClip.downloadUrl,
        "-i", audioPath,
        "-c:v", "libx264",
        "-c:a", "aac",
        "-vf", `scale=${width}:${height}:force_original_aspect_ratio=decrease,pad=${width}:${height}:(ow-iw)/2:(oh-ih)/2:color=black`,
        "-shortest",
        "-movflags", "+faststart",
        "-y",
        outputPath
      ];

      console.log("FFmpeg command:", "ffmpeg", args.join(" "));

      const ffmpeg = spawn("ffmpeg", args);
      
      let stderr = "";
      
      ffmpeg.stderr.on("data", (data) => {
        stderr += data.toString();
        console.log(`FFmpeg: ${data}`);
      });

      ffmpeg.on("close", (code) => {
        if (code === 0) {
          console.log("Video created successfully!");
          resolve();
        } else {
          console.error("FFmpeg stderr:", stderr);
          reject(new Error(`FFmpeg process exited with code ${code}. Error: ${stderr}`));
        }
      });

      ffmpeg.on("error", (error) => {
        reject(new Error(`FFmpeg spawn error: ${error.message}`));
      });
    });

    // Cleanup temp directory
    if (fs.existsSync(tempDir)) {
      fs.rmSync(tempDir, { recursive: true, force: true });
    }

    return outputPath;
  } catch (error) {
    throw new Error(`Failed to create simple video: ${error}`);
  }
}

async function createTextOnlyVideo(
  audioFiles: Array<{ audioUrl: string; duration: number }>,
  options: SimpleVideoOptions
): Promise<string> {
  try {
    const audioFile = audioFiles[0];
    const audioPath = path.join(process.cwd(), audioFile.audioUrl.replace('/uploads/', 'uploads/'));
    
    // Verify audio file exists
    if (!fs.existsSync(audioPath)) {
      throw new Error(`Audio file not found: ${audioPath}`);
    }

    const outputPath = options.outputPath;
    
    // Ensure output directory exists
    const outputDir = path.dirname(outputPath);
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
    }

    const resolutionMap = {
      "720p": { width: 1280, height: 720 },
      "1080p": { width: 1920, height: 1080 }
    };
    
    const { width, height } = resolutionMap[options.resolution];

    await new Promise<void>((resolve, reject) => {
      // Create a video with solid background and audio
      const args = [
        "-f", "lavfi",
        "-i", `color=c=black:s=${width}x${height}:d=${audioFile.duration}`,
        "-i", audioPath,
        "-c:v", "libx264",
        "-c:a", "aac",
        "-shortest",
        "-movflags", "+faststart",
        "-y",
        outputPath
      ];

      console.log("FFmpeg command (text-only):", "ffmpeg", args.join(" "));

      const ffmpeg = spawn("ffmpeg", args);
      
      let stderr = "";
      
      ffmpeg.stderr.on("data", (data) => {
        stderr += data.toString();
        console.log(`FFmpeg: ${data}`);
      });

      ffmpeg.on("close", (code) => {
        if (code === 0) {
          console.log("Text-only video created successfully!");
          resolve();
        } else {
          console.error("FFmpeg stderr:", stderr);
          reject(new Error(`FFmpeg process exited with code ${code}. Error: ${stderr}`));
        }
      });

      ffmpeg.on("error", (error) => {
        reject(new Error(`FFmpeg spawn error: ${error.message}`));
      });
    });

    return outputPath;
  } catch (error) {
    throw new Error(`Failed to create text-only video: ${error}`);
  }
}