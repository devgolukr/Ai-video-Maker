import * as fs from "fs";
import * as path from "path";
import { spawn } from "child_process";
import { VideoClip } from "./stockFootage";

export interface EnhancedVideoOptions {
  outputPath: string;
  resolution: "720p" | "1080p";
}

export async function createEnhancedVideo(
  audioFiles: Array<{ audioUrl: string; duration: number }>,
  videoClips: Array<{ clips: VideoClip[]; targetDuration: number; scene?: any }>,
  options: EnhancedVideoOptions
): Promise<string> {
  try {
    const tempDir = path.join(process.cwd(), "temp", `enhanced_video_${Date.now()}`);
    
    // Create temp directory
    if (!fs.existsSync(tempDir)) {
      fs.mkdirSync(tempDir, { recursive: true });
    }

    console.log(`Processing ${audioFiles.length} audio files and ${videoClips.length} video clip groups`);

    // Check if we have video clips
    if (videoClips.length === 0 || videoClips.every(vc => vc.clips.length === 0)) {
      console.log("No video clips available, creating audio-only video with black background");
      return await createAudioOnlyVideo(audioFiles, options, tempDir);
    }

    // Create individual scene videos
    const sceneVideos: string[] = [];
    const maxScenes = Math.max(audioFiles.length, videoClips.length);
    
    for (let i = 0; i < maxScenes; i++) {
      const audioFile = audioFiles[i] || audioFiles[audioFiles.length - 1]; // Use last audio if not enough
      const sceneClips = videoClips[i]?.clips || [];
      
      if (sceneClips.length === 0) {
        console.log(`No video clips for scene ${i}, using color background`);
        const sceneVideo = await createSceneWithBackground(audioFile, i, tempDir, options);
        sceneVideos.push(sceneVideo);
      } else {
        // Use the best available clip for this scene
        const videoClip = sceneClips[0];
        const sceneVideo = await createSceneVideo(audioFile, videoClip, i, tempDir, options);
        sceneVideos.push(sceneVideo);
      }
    }

    console.log(`Created ${sceneVideos.length} scene videos, now concatenating...`);

    // Concatenate all scene videos
    const finalVideo = await concatenateSceneVideos(sceneVideos, options.outputPath, tempDir);

    // Cleanup temp directory
    if (fs.existsSync(tempDir)) {
      fs.rmSync(tempDir, { recursive: true, force: true });
    }

    console.log("Enhanced video creation completed successfully!");
    return finalVideo;
  } catch (error) {
    console.error("Enhanced video creation failed:", error);
    throw new Error(`Failed to create enhanced video: ${error}`);
  }
}

async function createSceneVideo(
  audioFile: { audioUrl: string; duration: number },
  videoClip: VideoClip,
  sceneIndex: number,
  tempDir: string,
  options: EnhancedVideoOptions
): Promise<string> {
  const audioPath = path.join(process.cwd(), audioFile.audioUrl.replace('/uploads/', 'uploads/'));
  const sceneOutputPath = path.join(tempDir, `scene_${sceneIndex}.mp4`);
  
  // Verify audio file exists
  if (!fs.existsSync(audioPath)) {
    throw new Error(`Audio file not found: ${audioPath}`);
  }

  const resolutionMap = {
    "720p": { width: 1280, height: 720 },
    "1080p": { width: 1920, height: 1080 }
  };
  
  const { width, height } = resolutionMap[options.resolution];

  await new Promise<void>((resolve, reject) => {
    const args = [
      "-i", videoClip.downloadUrl,
      "-i", audioPath,
      "-c:v", "libx264",
      "-c:a", "aac",
      "-vf", `scale=${width}:${height}:force_original_aspect_ratio=decrease,pad=${width}:${height}:(ow-iw)/2:(oh-ih)/2:color=black`,
      "-t", audioFile.duration.toString(), // Limit to audio duration
      "-preset", "fast", // Fast encoding
      "-crf", "23", // Good quality
      "-movflags", "+faststart",
      "-y",
      sceneOutputPath
    ];

    console.log(`Creating scene ${sceneIndex} with video clip: ${videoClip.id}`);

    const ffmpeg = spawn("ffmpeg", args, { stdio: ['pipe', 'pipe', 'pipe'] });
    
    let stderr = "";
    
    ffmpeg.stderr.on("data", (data) => {
      stderr += data.toString();
      // Only log progress for first scene to avoid spam
      if (sceneIndex === 0) {
        const progressMatch = data.toString().match(/time=(\d+:\d+:\d+.\d+)/);
        if (progressMatch) {
          console.log(`Scene ${sceneIndex} progress: ${progressMatch[1]}`);
        }
      }
    });

    ffmpeg.on("close", (code) => {
      if (code === 0) {
        console.log(`Scene ${sceneIndex} created successfully!`);
        resolve();
      } else {
        console.error(`Scene ${sceneIndex} failed with code ${code}`);
        console.error("Error details:", stderr.slice(-500)); // Last 500 chars
        reject(new Error(`Scene ${sceneIndex} FFmpeg failed with code ${code}`));
      }
    });

    ffmpeg.on("error", (error) => {
      reject(new Error(`Scene ${sceneIndex} spawn error: ${error.message}`));
    });
  });

  return sceneOutputPath;
}

async function createSceneWithBackground(
  audioFile: { audioUrl: string; duration: number },
  sceneIndex: number,
  tempDir: string,
  options: EnhancedVideoOptions
): Promise<string> {
  const audioPath = path.join(process.cwd(), audioFile.audioUrl.replace('/uploads/', 'uploads/'));
  const sceneOutputPath = path.join(tempDir, `scene_${sceneIndex}.mp4`);
  
  const resolutionMap = {
    "720p": { width: 1280, height: 720 },
    "1080p": { width: 1920, height: 1080 }
  };
  
  const { width, height } = resolutionMap[options.resolution];

  await new Promise<void>((resolve, reject) => {
    const args = [
      "-f", "lavfi",
      "-i", `color=c=#1a1a1a:s=${width}x${height}:d=${audioFile.duration}:r=25`,
      "-i", audioPath,
      "-c:v", "libx264",
      "-c:a", "aac",
      "-preset", "fast",
      "-crf", "23",
      "-shortest",
      "-movflags", "+faststart",
      "-y",
      sceneOutputPath
    ];

    console.log(`Creating background scene ${sceneIndex}`);

    const ffmpeg = spawn("ffmpeg", args, { stdio: ['pipe', 'pipe', 'pipe'] });
    
    let stderr = "";
    
    ffmpeg.stderr.on("data", (data) => {
      stderr += data.toString();
    });

    ffmpeg.on("close", (code) => {
      if (code === 0) {
        console.log(`Background scene ${sceneIndex} created successfully!`);
        resolve();
      } else {
        console.error(`Background scene ${sceneIndex} failed:`, stderr.slice(-300));
        reject(new Error(`Background scene ${sceneIndex} failed with code ${code}`));
      }
    });

    ffmpeg.on("error", (error) => {
      reject(new Error(`Background scene ${sceneIndex} spawn error: ${error.message}`));
    });
  });

  return sceneOutputPath;
}

async function concatenateSceneVideos(
  sceneVideos: string[],
  outputPath: string,
  tempDir: string
): Promise<string> {
  // Ensure output directory exists
  const outputDir = path.dirname(outputPath);
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }

  if (sceneVideos.length === 1) {
    // If only one scene, just copy it
    fs.copyFileSync(sceneVideos[0], outputPath);
    console.log("Single scene video copied to output");
    return outputPath;
  }

  // Create a list file for concatenation
  const listFilePath = path.join(tempDir, "scenes_list.txt");
  const listContent = sceneVideos.map(video => `file '${path.resolve(video)}'`).join('\n');
  fs.writeFileSync(listFilePath, listContent, 'utf8');

  console.log(`Concatenating ${sceneVideos.length} scenes...`);
  console.log("List file content:", listContent);

  await new Promise<void>((resolve, reject) => {
    const args = [
      "-f", "concat",
      "-safe", "0",
      "-i", listFilePath,
      "-c", "copy",
      "-movflags", "+faststart",
      "-y",
      outputPath
    ];

    console.log("Concatenation command:", "ffmpeg", args.join(" "));

    const ffmpeg = spawn("ffmpeg", args, { stdio: ['pipe', 'pipe', 'pipe'] });
    
    let stderr = "";
    
    ffmpeg.stderr.on("data", (data) => {
      stderr += data.toString();
      console.log(`Concat: ${data}`);
    });

    ffmpeg.on("close", (code) => {
      if (code === 0) {
        console.log("All scenes concatenated successfully!");
        resolve();
      } else {
        console.error("Concatenation failed with code:", code);
        console.error("Full error:", stderr);
        reject(new Error(`Concatenation failed with code ${code}`));
      }
    });

    ffmpeg.on("error", (error) => {
      reject(new Error(`Concatenation spawn error: ${error.message}`));
    });
  });

  return outputPath;
}

async function createAudioOnlyVideo(
  audioFiles: Array<{ audioUrl: string; duration: number }>,
  options: EnhancedVideoOptions,
  tempDir: string
): Promise<string> {
  console.log("Creating audio-only video with multiple tracks");
  
  // First, concatenate all audio files
  const audioList = path.join(tempDir, "audio_list.txt");
  const audioContent = audioFiles.map(audio => {
    const audioPath = path.join(process.cwd(), audio.audioUrl.replace('/uploads/', 'uploads/'));
    return `file '${path.resolve(audioPath)}'`;
  }).join('\n');
  
  fs.writeFileSync(audioList, audioContent, 'utf8');
  
  const combinedAudioPath = path.join(tempDir, "combined_audio.mp3");
  
  // Concatenate audio files
  await new Promise<void>((resolve, reject) => {
    const args = [
      "-f", "concat",
      "-safe", "0",
      "-i", audioList,
      "-c", "copy",
      "-y",
      combinedAudioPath
    ];

    const ffmpeg = spawn("ffmpeg", args);
    
    ffmpeg.on("close", (code) => {
      if (code === 0) {
        resolve();
      } else {
        reject(new Error(`Audio concatenation failed with code ${code}`));
      }
    });

    ffmpeg.on("error", (error) => {
      reject(new Error(`Audio concatenation error: ${error.message}`));
    });
  });

  // Get total duration
  const totalDuration = audioFiles.reduce((sum, audio) => sum + audio.duration, 0);
  
  const resolutionMap = {
    "720p": { width: 1280, height: 720 },
    "1080p": { width: 1920, height: 1080 }
  };
  
  const { width, height } = resolutionMap[options.resolution];

  // Create video with combined audio
  await new Promise<void>((resolve, reject) => {
    const args = [
      "-f", "lavfi",
      "-i", `color=c=#1a1a1a:s=${width}x${height}:d=${totalDuration}:r=25`,
      "-i", combinedAudioPath,
      "-c:v", "libx264",
      "-c:a", "aac",
      "-preset", "fast",
      "-crf", "23",
      "-shortest",
      "-movflags", "+faststart",
      "-y",
      options.outputPath
    ];

    const ffmpeg = spawn("ffmpeg", args);
    
    let stderr = "";
    
    ffmpeg.stderr.on("data", (data) => {
      stderr += data.toString();
      console.log(`Audio-only video: ${data}`);
    });

    ffmpeg.on("close", (code) => {
      if (code === 0) {
        console.log("Audio-only video created successfully!");
        resolve();
      } else {
        console.error("Audio-only video failed:", stderr);
        reject(new Error(`Audio-only video failed with code ${code}`));
      }
    });

    ffmpeg.on("error", (error) => {
      reject(new Error(`Audio-only video error: ${error.message}`));
    });
  });

  return options.outputPath;
}