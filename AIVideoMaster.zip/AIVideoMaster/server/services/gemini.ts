import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ 
  apiKey: process.env.GEMINI_API_KEY!
});

export interface VideoScript {
  title: string;
  scenes: Array<{
    narration: string;
    duration: number;
    visualDescription: string;
    keywords: string[];
  }>;
  totalDuration: number;
  tone: string;
}

export async function generateVideoScript(
  prompt: string,
  duration: string,
  style: string
): Promise<VideoScript> {
  try {
    const systemPrompt = `You are a professional video script writer. Create a detailed video script based on the user's prompt.
The script should be engaging, well-structured, and suitable for AI voiceover.

Duration target: ${duration}
Style: ${style}

Return a JSON response with this structure:
{
  "title": "Video title",
  "scenes": [
    {
      "narration": "Text to be spoken",
      "duration": 15,
      "visualDescription": "Description of what should be shown visually",
      "keywords": ["keyword1", "keyword2", "keyword3"]
    }
  ],
  "totalDuration": 120,
  "tone": "professional/casual/educational"
}

Make sure the narration flows naturally and the visual descriptions are specific enough to find relevant stock footage.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            title: { type: "string" },
            scenes: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  narration: { type: "string" },
                  duration: { type: "number" },
                  visualDescription: { type: "string" },
                  keywords: {
                    type: "array",
                    items: { type: "string" }
                  }
                },
                required: ["narration", "duration", "visualDescription", "keywords"]
              }
            },
            totalDuration: { type: "number" },
            tone: { type: "string" }
          },
          required: ["title", "scenes", "totalDuration", "tone"]
        }
      },
      contents: prompt
    });

    const rawJson = response.text;
    if (!rawJson) {
      throw new Error("Empty response from Gemini API");
    }

    const script: VideoScript = JSON.parse(rawJson);
    return script;
  } catch (error) {
    throw new Error(`Failed to generate script: ${error}`);
  }
}

export async function optimizeScriptForFootage(script: VideoScript): Promise<VideoScript> {
  try {
    const systemPrompt = `You are tasked with optimizing a video script for stock footage availability.
Review the visual descriptions and keywords to ensure they can be matched with commonly available stock footage.
Suggest more specific, searchable terms while maintaining the script's intent.

Return the same JSON structure but with optimized visual descriptions and keywords that are more likely to match stock footage.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            title: { type: "string" },
            scenes: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  narration: { type: "string" },
                  duration: { type: "number" },
                  visualDescription: { type: "string" },
                  keywords: {
                    type: "array",
                    items: { type: "string" }
                  }
                },
                required: ["narration", "duration", "visualDescription", "keywords"]
              }
            },
            totalDuration: { type: "number" },
            tone: { type: "string" }
          },
          required: ["title", "scenes", "totalDuration", "tone"]
        }
      },
      contents: JSON.stringify(script)
    });

    const rawJson = response.text;
    if (!rawJson) {
      throw new Error("Empty response from Gemini API");
    }

    const optimizedScript: VideoScript = JSON.parse(rawJson);
    return optimizedScript;
  } catch (error) {
    console.warn("Failed to optimize script, using original:", error);
    return script;
  }
}
