import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { type VideoGeneration } from "@shared/schema";

interface ProgressTrackerProps {
  generation: VideoGeneration;
  onComplete: (generation: VideoGeneration) => void;
}

const STEPS = [
  { key: "script", name: "Script Generation", icon: "📝" },
  { key: "voiceover", name: "Voiceover Generation", icon: "🎤" },
  { key: "footage", name: "Stock Footage Selection", icon: "🎬" },
  { key: "editing", name: "Video Editing & Assembly", icon: "✂️" },
];

export function ProgressTracker({ generation, onComplete }: ProgressTrackerProps) {
  const { data: currentGeneration, refetch } = useQuery({
    queryKey: [`/api/video-generation/${generation.id}`],
    refetchInterval: 2000, // Poll every 2 seconds
    enabled: generation.status !== "completed" && generation.status !== "failed",
  });

  const activeGeneration = currentGeneration || generation;
  const metadata = activeGeneration.metadata as any;
  const currentStep = metadata?.currentStep || "script";
  const progress = metadata?.progress || 0;

  useEffect(() => {
    if (activeGeneration.status === "completed") {
      onComplete(activeGeneration);
    }
  }, [activeGeneration.status, activeGeneration, onComplete]);

  const getStepStatus = (stepKey: string) => {
    const stepIndex = STEPS.findIndex(s => s.key === stepKey);
    const currentStepIndex = STEPS.findIndex(s => s.key === currentStep);
    
    if (stepIndex < currentStepIndex) return "complete";
    if (stepIndex === currentStepIndex) return "active";
    return "pending";
  };

  if (activeGeneration.status === "failed") {
    return (
      <div className="glass-card rounded-2xl p-8 shadow-2xl">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-destructive rounded-full mb-4">
            <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </div>
          <h3 className="text-2xl font-bold mb-2 text-destructive">Generation Failed</h3>
          <p className="text-muted-foreground">There was an error creating your video.</p>
          {metadata?.error && (
            <p className="text-sm text-muted-foreground/70 mt-2">{metadata.error}</p>
          )}
        </div>
        <Button 
          onClick={() => window.location.reload()}
          className="w-full bg-muted hover:bg-muted/80 text-foreground"
        >
          Try Again
        </Button>
      </div>
    );
  }

  return (
    <div className="glass-card rounded-2xl p-8 shadow-2xl">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 gradient-primary rounded-full mb-4">
          <svg className="animate-spin w-8 h-8 text-white" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
        </div>
        <h3 className="text-2xl font-bold mb-2">Creating Your Video</h3>
        <p className="text-muted-foreground">Our AI is working its magic...</p>
      </div>

      <div className="space-y-4 mb-6">
        {STEPS.map((step) => {
          const status = getStepStatus(step.key);
          return (
            <div
              key={step.key}
              className={`flex items-center justify-between p-4 bg-card rounded-lg border-l-4 ${
                status === "complete" 
                  ? "border-success" 
                  : status === "active" 
                    ? "border-primary" 
                    : "border-border"
              }`}
            >
              <div className="flex items-center space-x-3">
                {status === "complete" ? (
                  <svg className="w-5 h-5 text-success" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"/>
                  </svg>
                ) : status === "active" ? (
                  <svg className="w-5 h-5 text-primary animate-pulse" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M7 4a3 3 0 016 0v4a3 3 0 11-6 0V4zm4 10.93A7.001 7.001 0 0017 8a1 1 0 10-2 0A5 5 0 015 8a1 1 0 00-2 0 7.001 7.001 0 006 6.93V17H6a1 1 0 100 2h8a1 1 0 100-2h-3v-2.07z" clipRule="evenodd"/>
                  </svg>
                ) : (
                  <div className="w-5 h-5 rounded-full border-2 border-border"></div>
                )}
                <span className="text-lg">{step.icon}</span>
                <span>{step.name}</span>
              </div>
              <span className={`text-sm ${
                status === "complete" 
                  ? "text-success" 
                  : status === "active" 
                    ? "text-primary" 
                    : "text-muted-foreground"
              }`}>
                {status === "complete" ? "Complete" : status === "active" ? "In Progress" : "Pending"}
              </span>
            </div>
          );
        })}
      </div>

      <div>
        <div className="flex justify-between text-sm text-muted-foreground mb-2">
          <span>Overall Progress</span>
          <span>{progress}%</span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      <Button 
        variant="outline"
        className="w-full mt-6 bg-muted hover:bg-muted/80 text-foreground border-border"
        onClick={() => window.location.reload()}
      >
        <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
        </svg>
        Cancel Generation
      </Button>
    </div>
  );
}
