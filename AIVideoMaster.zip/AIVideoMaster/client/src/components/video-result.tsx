import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { type VideoGeneration } from "@shared/schema";
import { useEffect } from "react";

interface VideoResultProps {
  generation: VideoGeneration;
  onCreateAnother: () => void;
}

export function VideoResult({ generation, onCreateAnother }: VideoResultProps) {
  const { toast } = useToast();
  const metadata = generation.metadata as any;

  // Save video to local storage when generation completes
  useEffect(() => {
    if (generation.status === 'completed' && generation.videoUrl) {
      const savedVideos = JSON.parse(localStorage.getItem('videoforge_videos') || '[]');
      const newVideo = {
        id: generation.id,
        prompt: generation.prompt,
        videoUrl: generation.videoUrl,
        createdAt: generation.createdAt,
        duration: metadata?.script?.totalDuration || 0,
        style: generation.style
      };
      
      // Add to beginning of array (most recent first)
      const updatedVideos = [newVideo, ...savedVideos.filter((v: any) => v.id !== generation.id)];
      
      // Keep only last 10 videos to save space
      localStorage.setItem('videoforge_videos', JSON.stringify(updatedVideos.slice(0, 10)));
      
      toast({
        title: "Video saved locally",
        description: "Your video has been saved to browser storage.",
      });
    }
  }, [generation, metadata, toast]);

  const handleDownload = async () => {
    try {
      const response = await fetch(`/api/video-generation/${generation.id}/download`);
      if (!response.ok) {
        throw new Error("Failed to download video");
      }
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `VideoForge_AI_${generation.id}.mp4`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "Download started",
        description: "Your video is being downloaded.",
      });
    } catch (error) {
      toast({
        title: "Download failed",
        description: "There was an error downloading your video.",
        variant: "destructive",
      });
    }
  };

  const handleShare = () => {
    if (navigator.share && generation.videoUrl) {
      navigator.share({
        title: "Check out my AI-generated video!",
        text: "I created this video using VideoForge AI",
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link copied",
        description: "Share link has been copied to clipboard.",
      });
    }
  };

  const script = metadata?.script;
  const duration = script?.totalDuration ? `${Math.floor(script.totalDuration / 60)}:${(script.totalDuration % 60).toString().padStart(2, '0')}` : "Unknown";

  return (
    <div className="glass-card rounded-2xl p-8 shadow-2xl max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-20 h-20 gradient-primary rounded-full mb-6 animate-pulse">
          <svg className="w-10 h-10 text-white" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"/>
          </svg>
        </div>
        <h3 className="text-3xl font-bold mb-3 gradient-text">Video Generated Successfully!</h3>
        <p className="text-lg text-muted-foreground">Your professional AI-powered video is ready to share</p>
      </div>

      {/* Video Player */}
      <div className="bg-black rounded-2xl overflow-hidden mb-8 aspect-video shadow-2xl border border-gray-800">
        <div className="relative h-full bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
          {generation.videoUrl ? (
            <video 
              controls 
              className="w-full h-full object-cover rounded-2xl"
              poster="/api/placeholder/1920/1080"
              preload="metadata"
            >
              <source src={generation.videoUrl} type="video/mp4" />
              Your browser does not support the video tag.
            </video>
          ) : (
            <div className="text-center">
              <button className="w-24 h-24 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white/30 transition-colors mb-6 mx-auto">
                <svg className="w-10 h-10 text-white ml-1" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M6.3 2.841A1.5 1.5 0 004 4.11V15.89a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z"/>
                </svg>
              </button>
              <p className="text-muted-foreground text-lg">Video preview will appear here</p>
            </div>
          )}
          <div className="absolute bottom-4 left-4 bg-black/80 backdrop-blur-sm px-4 py-2 rounded-lg text-sm font-medium">
            <span className="text-white">⏱️ {duration}</span>
          </div>
          <div className="absolute top-4 right-4 bg-green-500/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-white">
            ✓ COMPLETED
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="glass-card p-6 rounded-xl">
          <div className="flex items-center mb-3">
            <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center mr-3">
              <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2a1 1 0 01-1 1H4a1 1 0 01-1-1V4zM3 10a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H4a1 1 0 01-1-1v-6zM14 9a1 1 0 00-1 1v6a1 1 0 001 1h2a1 1 0 001-1v-6a1 1 0 00-1-1h-2z"/>
              </svg>
            </div>
            <h4 className="font-semibold">Video Details</h4>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Duration</span>
              <span className="font-medium">{duration}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Resolution</span>
              <span className="font-medium">1920x1080</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Format</span>
              <span className="font-medium">MP4</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Style</span>
              <span className="font-medium capitalize">{generation.style}</span>
            </div>
          </div>
        </div>
        
        <div className="glass-card p-6 rounded-xl">
          <div className="flex items-center mb-3">
            <div className="w-8 h-8 bg-green-500 rounded-lg flex items-center justify-center mr-3">
              <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
              </svg>
            </div>
            <h4 className="font-semibold">Generation Stats</h4>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Script Scenes</span>
              <span className="font-medium">{script?.scenes?.length || 0}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Audio Files</span>
              <span className="font-medium">{metadata?.audioFiles || 0}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Video Clips</span>
              <span className="font-medium">{metadata?.videoClips || 0}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Created</span>
              <span className="font-medium">Just now</span>
            </div>
          </div>
        </div>
        
        <div className="glass-card p-6 rounded-xl">
          <div className="flex items-center mb-3">
            <div className="w-8 h-8 bg-purple-500 rounded-lg flex items-center justify-center mr-3">
              <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path d="M5 3a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2V5a2 2 0 00-2-2H5zM5 11a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2H5zM11 5a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V5zM11 13a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/>
              </svg>
            </div>
            <h4 className="font-semibold">Storage Info</h4>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Saved Locally</span>
              <span className="font-medium text-green-600">✓ Yes</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Video ID</span>
              <span className="font-medium">#{generation.id}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">File Size</span>
              <span className="font-medium">~{Math.round((script?.totalDuration || 30) * 0.5)}MB</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Quality</span>
              <span className="font-medium">HD 1080p</span>
            </div>
          </div>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <Button 
          onClick={handleDownload}
          size="lg"
          className="flex-1 gradient-primary hover:opacity-90 text-primary-foreground font-semibold py-4 rounded-xl transition-all duration-300 shadow-lg hover:shadow-xl"
        >
          <svg className="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
          Download Video
        </Button>
        <Button 
          onClick={handleShare}
          variant="outline"
          size="lg"
          className="flex-1 glass-card hover:bg-muted/50 text-foreground border-border py-4 rounded-xl transition-all duration-300 font-semibold"
        >
          <svg className="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.367 2.684 3 3 0 00-5.367-2.684z" />
          </svg>
          Share Video
        </Button>
        <Button 
          onClick={onCreateAnother}
          size="lg"
          className="bg-accent hover:bg-accent/80 text-accent-foreground px-8 py-4 rounded-xl transition-all duration-300 font-semibold shadow-lg hover:shadow-xl"
        >
          <svg className="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
          </svg>
          Create Another
        </Button>
      </div>
    </div>
  );
}
