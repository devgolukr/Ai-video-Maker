import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { type VideoGeneration } from "@shared/schema";

interface VideoGeneratorProps {
  onGenerationStart: (generation: VideoGeneration) => void;
}

export function VideoGenerator({ onGenerationStart }: VideoGeneratorProps) {
  const [prompt, setPrompt] = useState("");
  const [duration, setDuration] = useState("");
  const [style, setStyle] = useState("");
  const [voiceGender, setVoiceGender] = useState("");
  const { toast } = useToast();

  const generateVideoMutation = useMutation({
    mutationFn: async (data: { prompt: string; duration: string; style: string; voiceGender: string }) => {
      const response = await apiRequest("POST", "/api/video-generation", data);
      return response.json();
    },
    onSuccess: (generation: VideoGeneration) => {
      toast({
        title: "Video generation started!",
        description: "Your AI video is being created. This may take a few minutes.",
      });
      onGenerationStart(generation);
    },
    onError: (error) => {
      toast({
        title: "Failed to start generation",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!prompt.trim()) {
      toast({
        title: "Please describe your video idea",
        description: "We need a description to create your video.",
        variant: "destructive",
      });
      return;
    }

    generateVideoMutation.mutate({
      prompt: prompt.trim(),
      duration: duration || "2 minutes",
      style: style || "professional",
      voiceGender: voiceGender || "neutral",
    });
  };

  return (
    <div className="glass-card rounded-2xl p-8 shadow-2xl">
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <Label className="text-lg font-semibold mb-3 flex items-center">
            <svg className="w-5 h-5 text-primary mr-2" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd"/>
            </svg>
            Describe your video idea
          </Label>
          <Textarea
            placeholder="Example: Create a 2-minute video about sustainable living tips, including practical advice for reducing carbon footprint at home..."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="h-32 bg-card border-border text-foreground placeholder-muted-foreground focus:border-primary resize-none"
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <Label className="text-sm mb-2 block">Video Length</Label>
            <Select value={duration} onValueChange={setDuration}>
              <SelectTrigger className="bg-card border-border text-foreground focus:border-primary">
                <SelectValue placeholder="Video Length" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="30 seconds">30 seconds</SelectItem>
                <SelectItem value="1 minute">1 minute</SelectItem>
                <SelectItem value="2 minutes">2 minutes</SelectItem>
                <SelectItem value="5 minutes">5 minutes</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label className="text-sm mb-2 block">Video Style</Label>
            <Select value={style} onValueChange={setStyle}>
              <SelectTrigger className="bg-card border-border text-foreground focus:border-primary">
                <SelectValue placeholder="Video Style" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="professional">Professional</SelectItem>
                <SelectItem value="casual">Casual</SelectItem>
                <SelectItem value="educational">Educational</SelectItem>
                <SelectItem value="promotional">Promotional</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label className="text-sm mb-2 block">Voice Gender</Label>
            <Select value={voiceGender} onValueChange={setVoiceGender}>
              <SelectTrigger className="bg-card border-border text-foreground focus:border-primary">
                <SelectValue placeholder="Voice Gender" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="male">Male</SelectItem>
                <SelectItem value="female">Female</SelectItem>
                <SelectItem value="neutral">Neutral</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Button 
          type="submit"
          disabled={generateVideoMutation.isPending}
          className="w-full gradient-primary hover:opacity-90 text-primary-foreground font-semibold py-4 rounded-xl transition-all duration-300 transform hover:scale-105 shadow-lg"
        >
          {generateVideoMutation.isPending ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-primary-foreground" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Creating Your Video...
            </>
          ) : (
            <>
              <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd"/>
              </svg>
              Generate Video with AI
            </>
          )}
        </Button>
      </form>
    </div>
  );
}
