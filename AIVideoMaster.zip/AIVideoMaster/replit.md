# VideoForge AI - AI Video Generation Platform

## Overview

VideoForge AI is a full-stack web application that generates videos from text prompts using artificial intelligence. The platform integrates multiple AI services to create a seamless video generation pipeline, from script writing to final video assembly. Users can input a description of their desired video and receive a professionally edited video with voiceover, stock footage, and transitions.

## System Architecture

This is a monorepo application with a clear separation between frontend and backend components:

- **Frontend**: React-based SPA using Vite as the build tool
- **Backend**: Express.js REST API server
- **Database**: PostgreSQL with Drizzle ORM
- **Shared**: Common TypeScript types and schemas

The architecture follows a modular design pattern with clear separation of concerns:
- API routes handle HTTP requests and responses
- Service layer manages external integrations
- Storage layer abstracts database operations
- Shared schema ensures type safety across frontend and backend

## Key Components

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite with hot module replacement
- **UI Library**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Database ORM**: Drizzle with PostgreSQL
- **File Upload**: Multer middleware with local storage
- **External APIs**: Google Gemini, ElevenLabs, Pexels integration
- **Video Processing**: FFmpeg-based video manipulation

### Database Schema
- **Users**: Basic user authentication system
- **Video Generations**: Tracks video creation requests with status, metadata, and file URLs
- **Database Provider**: Configured for PostgreSQL with Neon Database support

### External Service Integrations
- **Google Gemini AI**: Script generation and content optimization
- **ElevenLabs**: AI voice synthesis for narration
- **Pexels**: Stock footage and imagery sourcing
- **FFmpeg**: Video processing and assembly

## Data Flow

1. **User Input**: User submits video prompt with preferences (duration, style, voice)
2. **Script Generation**: Gemini AI creates structured video script with scenes
3. **Voiceover Creation**: ElevenLabs generates audio for each scene
4. **Footage Selection**: Pexels API sources relevant stock footage
5. **Video Assembly**: FFmpeg combines audio, video, and transitions
6. **Progress Tracking**: Real-time status updates via polling
7. **Final Delivery**: Completed video served to user

The application uses asynchronous processing for video generation, allowing users to monitor progress through a polling-based system that updates the UI in real-time.

## External Dependencies

### Core Framework Dependencies
- React ecosystem (React, React DOM, React Query)
- Express.js with middleware (multer, express sessions)
- Drizzle ORM with PostgreSQL driver

### UI and Styling
- Radix UI primitives for accessible components
- Tailwind CSS for utility-first styling
- Shadcn/ui component library

### External APIs
- Google Gemini AI for content generation
- ElevenLabs for voice synthesis
- Pexels for stock media

### Development Tools
- TypeScript for type safety
- Vite for fast development builds
- ESBuild for production bundling

## Deployment Strategy

The application is configured for deployment on Replit with the following setup:

- **Development**: `npm run dev` starts both frontend and backend in development mode
- **Production Build**: `npm run build` creates optimized bundles for both client and server
- **Production Start**: `npm start` runs the production server

The build process:
1. Vite builds the frontend React application
2. ESBuild bundles the backend Express server
3. Static assets are served from the dist/public directory
4. Database migrations are managed through Drizzle Kit

Environment variables required:
- `DATABASE_URL`: PostgreSQL connection string
- `GEMINI_API_KEY`: Google AI API access
- `ELEVENLABS_API_KEY`: Voice synthesis service
- `PEXELS_API_KEY`: Stock footage access

## Changelog

```
Changelog:
- July 08, 2025. Initial setup
- July 08, 2025. Enhanced video processing system - Fixed multi-scene video generation to properly merge all video clips instead of showing only first clip. Added enhanced video processor with scene concatenation, fallback mechanisms for missing footage, and improved error handling. Updated UI with professional design, local video storage in browser, and comprehensive video stats display.
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```